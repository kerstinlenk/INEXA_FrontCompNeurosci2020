%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main.m: Main file of the INEXA tool 
% author: Kerstin Lenk & Eero Satuvuori & Antonio Ladron-de-Guevara
% date: 2013-2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%  preparation
rng shuffle;
disp('Started')

%% Start clock to measure performance
tic

%% Set configuration settings in general and for neurons
Config_Neuron;

% time interval in [msec]
tinMS = t * 1000; 

% Number of neurons
numNeur = in0+ex0; 

%% Run astrocyte config
Config_Astrocyte;

%% Directory of the INEXA tool
directory2 = pwd; 

% Make directory for results
mkdir(directory);

%% Brute Force Method
param_c = c_k(1,1):c_k(2,1):c_k(3,1);
param_oex0 = synStr_oex0(1,1):synStr_oex0(2,1):synStr_oex0(3,1);
param_oin0 = synStr_oin0(1,1):synStr_oin0(2,1):synStr_oin0(3,1);

%% Check lower and upper boundaries for neurons
if isempty(param_c) == 1
    param_c = 0;
end
if c_k(1,1) == c_k(3,1)
    param_c = c_k(1,1);
end
if isempty(param_oex0) == 1
    param_oex0 = 0;
end
if synStr_oex0(1,1) == synStr_oex0(3,1)
    param_oex0 = synStr_oex0(1,1);
end
if isempty(param_oin0) == 1
    param_oin0 = 0;
end
if synStr_oin0(1,1) == synStr_oin0(3,1)
    param_oin0 = synStr_oin0(1,1);
end

%% Copy config files in result folder
copyfile('Config_Astrocyte.m',[directory,'Config_Astrocyte.m']);
copyfile('Config_Neuron.m',[directory,'Config_Neuron.m']);

%% Creating base network topology
if( MakeNewTopology )
    CreateNetworkTopology;
else
    %Loading from file and saving to results folder 
    Load_NetworkTopology;
    Save_NetworkTopology;
    
    % Setting basic activity to correspond this run    
    BaseBasicActivity = zeros(numNeur,1);   
    for i = 1:numNeur
        BaseBasicActivity(i,1) = trianrnd(0,1);
    end
end

%% Cycling through parameters
for p_c = param_c 
    for p_oex0  = param_oex0 
       	for p_oin0 = param_oin0
            
    %% Preparations for generations of spike trains
    setNeuronConfig;
    setAstrocyteConfig;

    infoNeurons = struct('j',[],'t',[],'synStr',[],'c',[],'f',[]);
    infoNeurons.j = numNeur;
    infoNeurons.t = t;
    infoNeurons.synStr = synStr;
    infoNeurons.c = c;
    infoNeurons.f = sensitivityMultiplier;

    
    %% Generate spike trains for all neurons
    for k = 1:tinMS:lengthST     
        sumS = 0;
 
        % ASTROCYTE SIMULATOR INTERFACE
        lastspike = OptimizedGenerateSpikeTrain(k,infoNeurons,lastspike,AstrocyteInhibition );
       
        sumS = sum(sum(lastspike(:,2))) + sumS;
        spikeTrain(:,k) = lastspike(:,2);
    
        lastspike(:,1) = lastspike(:,2);
        lastspike(:,2) = 0;
    
        if mod(counterSave,limitSave) == 0 || k == (lengthST-(t*1000)+1)
            INEX_SaveTimestamps;
            counterSave = 0;
            ct = ct + 1;
        end
        counterSave = counterSave + 1;   
        
        % ASTROCYTE SIMULATOR INTERFACE
        if(preSynapse)
            spikeVector = lastspike(:,1);
            ModifiedPreSynapseModel;
            Calculate_AstrocyteData;
            infoNeurons.synStr = returnValue;
        end 
    end
    
    % Save parameters in a txt-file
    Save_Parameters(synStr,c,directory,directory2,p_c,p_oex0,p_oin0);
    
    fclose(fid);
    
    % ASTROCYTE SIMULATOR INTERFACE
    Save_AstrocyteData;
    
        end
    end
end
 
disp('Finished')

cd(directory2)

%% End clock to measure performance
toc


