%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% trianrnd.m: Random number between a and b according to triangular 
% distribution
% author: Kerstin Lenk/ Barbara Priwitzer
% date: 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function r = trianrnd(a,b)
    
% Generate uniformly distributed random number between -1 and 1
r_h = unifrnd(-1,1);
x = rand(1,1);

% Model probability using random variable x: compare with traingular line,
% splitted in x>0 or x<0
bool = 1;
while (bool == 1)
    if (r_h>0 && x>(-1) *(r_h)+1 )
        r_h = unifrnd(-1,1);
        x = rand(1,1);
    elseif (r_h<=0 && x>(r_h)+1)
        r_h = unifrnd(-1,1);
        x = rand(1,1);
    else
        bool = 0;
    end
end

% Shift random number into intervall [a,b]
r = (r_h+1)*(b-a)/2+a;

end
