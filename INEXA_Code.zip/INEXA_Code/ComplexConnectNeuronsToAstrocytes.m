%% simple function for connecting neurons to astrocytes.

% Connects incoming connections to a neuron to nearest
% astrocyte/astrocytes. Counting probability of each synapse to be
% connected to an astrocyte and dividing synapses between astrocytes by
% their probability.
% 
function AstrocyteNeuronConnections = ComplexConnectNeuronsToAstrocytes( ...
    NeuronLocation,BaseNetwork, AstrocyteCoordinates, ANconnectivitySTD, ...
    MaxAstrocyteReachDistance)

%NeuronLocation = [ 10 10 20 60; 30 15 10 5; 10 10 30 15];
%AstrocyteCoordinates = [  15 100 200;  20 20 20;  5 5 5];
%BaseNetwork = [ 1 1 1 1; 1 0 0 1; 0 1 1 0 ; 0 0 0 0];

numNeur = length(NeuronLocation(1,:));
AmountOfAstrocytes = length(AstrocyteCoordinates(1,:));
AstrocyteNeuronConnections = zeros(numNeur,numNeur, AmountOfAstrocytes);
AstrocyteNeuronConnectionProbabilities = zeros(numNeur, AmountOfAstrocytes);
ExcitatorySynapses = 1*(BaseNetwork > 0);

% Calculating probability of each astrocyte to connect to synapses of a
% neuron.
for ii = 1:numNeur
    for i = 1:AmountOfAstrocytes
        distance = Distance(NeuronLocation(:,ii),AstrocyteCoordinates(:,i));
        
        if distance < MaxAstrocyteReachDistance
            GaussianStrength = ...
                ANconnectivitySTD*sqrt(2*pi)*normpdf(distance,0,ANconnectivitySTD);
            AstrocyteNeuronConnectionProbabilities(ii,i) = GaussianStrength;
            
        end
        
    end
    
end




% Finding out which astrocyte binds to which synapse
for ii = 1:numNeur
    
    [candidateStrengths, candidateOrder] = sort(AstrocyteNeuronConnectionProbabilities(ii,:),'descend');
    
    % When going through all the neurons if this incoming
    % connection is excitatory we try to connect an astrocyte to it
    for i = 1:numNeur
        if ExcitatorySynapses(i,ii) == 1
            
            NotAllocated = 1;
            candidateNumber = 1;
            
            while(candidateNumber <= AmountOfAstrocytes && ...
                    candidateStrengths(candidateNumber) > 0 && NotAllocated)
                
                if candidateStrengths(candidateNumber)> rand()
                    % Connecting astrocyte
                    AstrocyteNeuronConnections(i,ii, candidateOrder(candidateNumber)) = 1;
                    NotAllocated = 0;
                    
                end
                candidateNumber = candidateNumber +1;
            end
            
        end
    end
    
end

end


