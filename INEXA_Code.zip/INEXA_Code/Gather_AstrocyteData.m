%% This script gathers valuable information from astrocyte simulation to be saved

if( Astrocyte )
ASTRODATA1(end+1) = AVG_AstroGlutamate;
ASTRODATA2(end+1) = AVG_NMDAR; % 0 NOT IN USE
ASTRODATA3(end+1) = AVG_NMDAR_Glutamate; % NOT IN USE
ASTRODATA6(end+1) = AVG_CaInAstrocytes;

ASTRODATA7(end+1) = SING_SYNSTR;
ASTRODATA8(end+1) = SING_CAL;
ASTRODATA9(end+1) = SING_RR;
ASTRODATA10(end+1) = SING_IP3;
ASTRODATA11(end+1) = SING_CaInAstrocytes;
ASTRODATA12(end+1) = SING_Release;
ASTRODATA13(end+1) = SING_AstroGlutamate;
end

if( preSynapse )
ASTRODATA4(end+1) = AVG_EX_Weight ;
ASTRODATA5(end+1) = AVG_IN_Weight ;
end

