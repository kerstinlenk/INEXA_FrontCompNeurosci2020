%% Creates connections based on object locations with gaussian probability
% needs parameters of [3,objects] array of coordinates and standard
% deviation of connectivity
function connections = CreateGaussianConnections( Locations, std )

% Connections matrix has 0 for not connected and 1 for connected.
connections = zeros(length(Locations(1,:)),length(Locations(1,:)));

for i = 1:length(Locations(1,:))
    for ii = 1:length(Locations(1,:))
       distance = Distance(Locations(:,i),Locations(:,ii));
       
       GaussianProbabilityOfConnection = ...
           std*sqrt(2*pi)*normpdf(distance,0,std);
    
       connections(i,ii) = GaussianProbabilityOfConnection > rand();
    end
end
end

