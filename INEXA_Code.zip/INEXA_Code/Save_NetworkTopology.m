%% Script for saving network topology

cd(directory)
% Write in files

fidNNT = fopen('NeuronNetworkTopology.csv','wt');
for i = 1:3
    for ii = 1:length(NeuronLocation(1,:))
        fprintf(fidNNT,'%f;',NeuronLocation(i,ii));
    end
    fprintf(fidNNT,'\n');
end
fclose(fidNNT);

if (AstrocyteNetwork == 1)
    
    fidANT = fopen('AstrocyteNetworkTopology.csv','wt');
    for i = 1:3
        for ii = 1:NumberOfAstrocytes
            fprintf(fidANT,'%f;',AstrocyteCoordinates(i,ii));
        end
        fprintf(fidANT,'\n');
    end
    fclose(fidANT);
    
    fidANC = fopen('AstrocyteNeuronConnections.csv','wt');
    for iii = 1:NumberOfAstrocytes
        for i = 1:numNeur
            for ii = 1:numNeur
                fprintf(fidANC,'%f;',AstrocyteNeuronConnections(i,ii,iii));
            end
            fprintf(fidANC,'\n');
        end
        
    end
    fclose(fidANC);
end

fidBN = fopen('BaseNetwork.csv','wt');
for i = 1:numNeur
    for ii = 1:numNeur
        fprintf(fidBN,'%f;',BaseNetwork(i,ii));
    end
    fprintf(fidBN,'\n');
end
fclose(fidBN);

if (AstrocyteNetwork == 1)
    
    fidAC = fopen('AstrocyteConnections.csv','wt');
    for i = 1:NumberOfAstrocytes
        for ii = 1:NumberOfAstrocytes
            fprintf(fidAC,'%f;',AstrocyteConnections(i,ii));
        end
        fprintf(fidAC,'\n');
    end
    fclose(fidAC);
end

cd(directory2)
