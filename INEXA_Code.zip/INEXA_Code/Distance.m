%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Distance.m: Function for calculating distances between column 
% vector coordinates a and b
% author: Eero R�is�nen
% date: 2014 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 

function  distance  = Distance( a , b )

XDistanceSquared = (a(1,:) - b(1,:)).^2;
YDistanceSquared = (a(2,:) - b(2,:)).^2;
ZDistanceSquared = (a(3,:) - b(3,:)).^2;
distance = sqrt(XDistanceSquared+YDistanceSquared+ZDistanceSquared);


end

