%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% setAstrocteConfig.m: Astrocyte and presynapse setConfig
% author: Eero R�is�nen
% date: 2014 - 2018
% Sets the astrocytes ready. Base network topology is given
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(preSynapse)
    
    % Expanding presynapse values to all synapses. All synapses have values
    % based on config file and all non-connected synapses have zero. Only
    % exitatory synapses have alpha values.
    w = synStr;   
    x = ones(numNeur, numNeur) .* Resources .* ActiveSynapses;
    u = ones(numNeur, numNeur) .* Calcium .* ActiveSynapses;
    Glu = ones(numNeur, numNeur) .* AstrocyteGlutamate.* ActiveSynapses;
    
    % Scaling parameters between models
    maxWex = p_oex0;
    maxWin = p_oin0;
    
    if( maxWex <= maxWin)        
        ScalingMatrix = ones(numNeur,numNeur)* maxWin;    
    end
    if( maxWex > maxWin)
        ScalingMatrix = ones(numNeur,numNeur)* maxWex;
    end
       
    % Scaling W:s between 0 and 1. Needs to be rescaled back in return value of
    % presynapse model!
    baseW = w;
    w = w./ScalingMatrix;
    
    % Auxiliary matrixes for model. Reserving memory.
    SpikingMatrix = zeros(numNeur, numNeur);
    Ualpha = zeros(numNeur, numNeur);
    Umatrix = zeros(numNeur, numNeur);
    RR = zeros(numNeur, numNeur);
    Alpha = zeros(numNeur, numNeur); 
    
    % General auxiliary matrix. Can be used in short computations and is
    % reserved by functions for only as long as they are run. 
    % **************STORES NO DATA****************
    AUX = zeros(numNeur, numNeur);
    
    % DATA gathering variables
    ASTRODATA1 = 0;
    ASTRODATA2 = 0;
    ASTRODATA3 = 0;
    ASTRODATA4 = 0;
    ASTRODATA5 = 0;
    ASTRODATA6 = 0;
    ASTRODATA7 = 0;
    ASTRODATA8 = 0;
    ASTRODATA9 = 0;
    ASTRODATA10 = 0;
    ASTRODATA11 = 0;
    ASTRODATA12 = 0;
    ASTRODATA13 = 0;
    
end

if (Astrocyte)
    
    % initializing variables
    IP3 = zeros(numNeur, numNeur);
    AstrocyteCa = zeros(numNeur, numNeur);
    ReleasingAstrocytes = zeros(numNeur, numNeur);
    OverThresholdSynapses = zeros(numNeur, numNeur);
    
    % Analysis and saving variables   
    
    AVG_AstroGlutamate = 0;
    AVG_EX_Weight = 0;
    AVG_IN_Weight = 0;
    AVG_CaInAstrocytes = 0;
    AstrocyteInhibition = zeros(1, numNeur);

    SING_SYNSTR = 0;
    SING_CAL = 0;
    SING_RR = 0;
    SING_IP3 = 0;
    SING_CaInAstrocytes = 0;   
    SING_Release = 0;
    SING_AstroGlutamate = 0;
    
end

if (AstrocyteNetwork)
    
    AstrocyteState = zeros(1,NumberOfAstrocytes);% 0 inactivated, 1 activated, -1 refractory
    ActivityAnimation(1:NumberOfAstrocytes,1:(floor(lengthST/tinMS))) = 0;
    AnimationFrame = 1;
    AmountOfAstrocytesActivatedInSimulation = 0; 
    TripartiteSynapseCalciums = zeros(numNeur, numNeur,NumberOfAstrocytes);
    CalciumAccumulationFromSynapses = zeros(1,NumberOfAstrocytes);
    CaEffect2D = zeros(numNeur, numNeur);
    CaEffect = zeros(numNeur, numNeur,NumberOfAstrocytes);
    
end
