
%% Creating data for analysis purposes for each round of simulation 

if( Astrocyte )
    %ASTRODATA1
    AVG_AstroGlutamate = sum(sum(Glu))/EX_Synapse_Amount;
    %ASTRODATA6 -> Astrocyte Calcium
    AVG_CaInAstrocytes = sum(sum(AstrocyteCa))/EX_Synapse_Amount;

     %Select a synapse
     if (k==1) % Only at the beginning
         [rows, cols] = find(SynapsesConnectedToAstrocyte == 1);
         index = round(length(rows)/2);
         ind_row = rows(index);
         ind_col = cols(index);
         indice_astrocyte = find(AstrocyteNeuronConnections(ind_row,ind_col,:)==1);
         ASTRODATA7(1) = ind_row;
         ASTRODATA8(1) = ind_col;
	 ASTRODATA2(1) = indice_astrocyte;
     end

    %ASTRODATA2 -> NOT IN USE
    AVG_NMDAR = CalciumAccumulationFromSynapses(indice_astrocyte);
    %ASTRODATA3 -> NOT IN USE
    AVG_NMDAR_Glutamate = FluxOut(indice_astrocyte);

     %ASTRODATA7 -> Synapse Stregth
     SING_SYNSTR = returnValue(ind_row,ind_col);
     %ASTRODATA8 -> Synapse Calcium
     SING_CAL = u(ind_row,ind_col);
     %ASTRODATA9 -> Resources Released
     SING_RR = RR(ind_row,ind_col);
     %ASTRODATA10 -> IP3
     SING_IP3 = IP3(ind_row,ind_col);
     %ASTRODATA11 -> Astrocyte Calcium
     SING_CaInAstrocytes = AstrocyteCa(ind_row,ind_col);
     %ASTRODATA12 -> Releasing of the astrocyte
     SING_Release = ReleasingAstrocytes(ind_row,ind_col);
     %ASTRODATA13 -> Glutamate
     SING_AstroGlutamate = Glu(ind_row,ind_col);
end
if( preSynapse )
    % ASTRODATA4 -> AVG Excitation
    AVG_EX_Weight = sum(sum(SpikingMatrix.*infoNeurons.synStr.*ExcitatorySynapses))/EX_Synapse_Amount;
    % ASTRODATA5 -> AVG Inhibition
    AVG_IN_Weight = -1* sum(sum(SpikingMatrix.*infoNeurons.synStr.*InhibitorySynapses))/IN_Synapse_Amount;
end

%% Using gather script to gather all the analysis data from whole simulation
Gather_AstrocyteData;
