%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save_Parameters.m: Save parameters in a txt-file
% author: Kerstin Lenk
% date: 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function saveParameters(a,c,directory,directory2,zz1,zz2,zz6)

    % Change directory
    cd(directory)

    % Open file
    fid2 = fopen(['parameters_',num2str(zz1,'%.4f'),'_',num2str(zz2,'%.4f'),...
        '_',num2str(zz6,'%.4f'),'.txt'],'wt');

    % Save parameters of synaptic strength
    fprintf(fid2,'%3.6f\n',a');

    % Save parameters of basic activity
    fprintf(fid2,'%d\n',c);

    % Close file
    fclose(fid2);

    % Change diectory
    cd(directory2)