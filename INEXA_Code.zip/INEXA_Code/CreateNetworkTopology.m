%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CreateNetworkTopology.m: Creates astrocyte and neuron network topologies
% author: Eero R�is�nen
% date: 2014 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Give each neuron spatial coordinates
% Use premade defined in PremadeNNTpath/NeuronNetworkTopology.csv or create new
if (UsePremadeNeuronNetwork)
    pathPremadeNN = [PremadeNNTpath, 'NeuronNetworkTopology','.csv'];
    import = importdata(pathPremadeNN);
    NeuronLocation = squeeze(import(:,:));
        
    pathPremadeBN = [PremadeNNTpath, 'BaseNetwork','.csv'];
    import = importdata(pathPremadeBN);
    BaseNetwork = squeeze(import(:,:));
    
    pathPremadeNNparameters = [PremadeNNTpath, 'parameters','.csv'];
    import = importdata(pathPremadeNNparameters);

    % The config files have to be checked that they have the same
    % parameters for neuronal network since that is where analyzer gets
    % information about the network.
    if ~(CultureSpace(1) == import(1,1) && CultureSpace(2) == import(1,2) && ...
        CultureSpace(3) == import(1,3) && MinimumNeuronDistance == import(2,1) && ...
        NeuroSTD == import(3,1) && in0 == import(6,1) && ex0 == import(4,1))
    
        error('Neuronal network parameters do not match the loaded network');

    end
    
    BaseBasicActivity = zeros(numNeur,1);
    for i = 1:numNeur
        
        BaseBasicActivity(i,1) = trianrnd(0,1);
        
    end
else
    NeuronLocation = DivideRandomlyToSpace( numNeur, MinimumNeuronDistance, CultureSpace );
        
    active = CreateGaussianConnections( NeuronLocation, NeuroSTD);
    
    % Basic activity of all neurons which is a random number between 0 and an
    % upper boundary from a triangular distribution
    BaseBasicActivity = zeros(numNeur,1);
    for i = 1:numNeur
        BaseBasicActivity(i,1) = trianrnd(0,1);
    end
    
    if (UsePremadeNeuronNetwork)
        
        pathBN = [PremadeNNTpath, 'BaseNetwork','.csv'];
        import = importdata(pathBN);
        BaseNetwork = squeeze(import(:,:));
               
    else
        
        BaseNetwork = zeros(numNeur,numNeur);
        % Excitatory synaptic strengths is a random number between 0 and an
        % upper boundary from a triangular distribution
        for i = 1:ex0 % Group 1
            for ii = 1:numNeur
                if i ~=ii
                    BaseNetwork(i,ii) = trianrnd(0,1);
                else
                    BaseNetwork(i,ii) = 0; % Autapses
                end
            end
        end
        % Inhibitory synaptic strengths is a random number between 0 and an
        % upper boundary from a triangular distribution
        for i = ex0+1:in0+ex0 % Group 1
            for ii = 1:numNeur
                if i ~=ii
                    BaseNetwork(i,ii) = trianrnd(0,-1);
                else
                    BaseNetwork(i,ii) = 0; % Autapses
                end
            end
        end      
        BaseNetwork(~active) = 0;
    end
end
%% Collecting useful values from the created network
% Finding all active synapses
ActiveSynapses = BaseNetwork ~=0;

% Finding all the excitatory and inhibitory synapses in the simulation .
ExcitatorySynapses = BaseNetwork > 0;
InhibitorySynapses = BaseNetwork < 0;

EX_Synapse_Amount = sum(sum(ExcitatorySynapses));
IN_Synapse_Amount = sum(sum(InhibitorySynapses));

% Finding synapse effect. Has values 1 for exitatory, 0 for not
% connected and -1 for negatives.
SynapseEffect = 1*(BaseNetwork > 0) + (-1)*(BaseNetwork < 0);

%% Creating astrocyte network
% Each column is connected to each astrocyte.
if (AstrocyteNetwork)
    AstrocyteNeuronConnections = zeros(numNeur, numNeur, NumberOfAstrocytes); %not connected yet.
    
    % Astrocytes are created
    AstrocyteCoordinates = ...
        DivideRandomlyToSpace( NumberOfAstrocytes, MinimumAstrocyteDistance, CultureSpace );
end
% Connecting astrocytes that ended up close enough to each other.
if(AstrocyteNetwork)
    AstrocyteConnections = ConnectAstrocytesByDistanceLimiter(AstrocyteCoordinates, connectionDistance);
    
    AmountOfConnections = sum(AstrocyteConnections);
    
    ActivationThreshold = slope * AmountOfConnections + intercept;
end

%% Connecting the two networks
% Dividing neurons among astrocytes
if(AstrocyteNetwork)
    AstrocyteNeuronConnections = ...
        ComplexConnectNeuronsToAstrocytes(NeuronLocation,BaseNetwork, AstrocyteCoordinates,...
        ANconnectivitySTD , MaxAstrocyteReachDistance);
    
    % Counting how many excitatory connections ended up to each astrocyte
    AmountOfExcitatoryConnectionsToTheAstrocyte = squeeze(sum(sum(AstrocyteNeuronConnections)))';
    
    % Counting which synapses are connected to an astrocyte to begin with
    SynapsesConnectedToAstrocyte = zeros(numNeur, numNeur); % Tripartite synapse indication matrix
    
    for i = 1:numNeur
        for ii = 1:numNeur         
            if sum(AstrocyteNeuronConnections(i,ii,:)) > 1
                error( ['synapse (' num2str(i) '|' num2str(ii) ') is connected to multiple astrocytes' ] );
            end
            SynapsesConnectedToAstrocyte(i,ii) = sum(AstrocyteNeuronConnections(i,ii,:));
        end
    end
end

%% Saving network topology
SaveNetworkTopology;
