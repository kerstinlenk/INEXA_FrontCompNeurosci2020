%% Divides neurons to space randomly with minimum distance.

function Location = DivideRandomlyToSpace( numberOfObjects, minimumDistance, Space )

NotReady = 1;
Try = 0;
Location = rand([3, numberOfObjects]).* repmat(Space',1,numberOfObjects);

while( NotReady )
    
    Move = zeros(1,numberOfObjects);
    % Setting flag so that if nothing is wrong the network is ready.
    NotReady = 0;
    
    % Counting how many times this has been tried to get it right.
    Try = Try +1;
    
    % Only trying 10000 times to get it right
    if Try > 10000
        error('Cannot allocate given amount of objects to given space with given distance');
    end
    
    % Checking all distances
    for i = 1:numberOfObjects
        % Checking connections only once thus from i forwards
        for ii = i:numberOfObjects
            
            % Not checking with itself or this will never end...
            if(i ~= ii)
                if Distance(Location(:,i),Location(:,ii)) < minimumDistance
                    
                    % If distance is less between these two one of them is
                    % moved randomly
                    if rand() > 0.5  
                        Move( i ) = 1;
                    else
                        Move( ii ) = 1;
                    end
                    % flagging the set not ready for another checking round
                    NotReady = 1;
                end
            end
        end
    end
    
    % move all those that needed to be moved
    for i = 1:numberOfObjects
        if Move(i) == 1
            Location(:,i) = rand([3, 1]).*Space';
        end
    end
end %while

end %function

