%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load_NetworkTopology.m: Loads topology from given file
% author: Eero R�is�nen
% date: 2014 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Creating paths to data files
pathNNT = [PremadeNNTpath, 'NeuronNetworkTopology','.csv'];
pathBN = [PremadeNNTpath, 'BaseNetwork','.csv'];

% Load the parameters used to create the neuron network and compare to the
% current parameters. 
pathParam = [PremadeNNTpath, 'parameters','.csv'];
importNN = importdata(pathParam);

% The config files have to be checked that they have the same
% parameters for neuronal network since that is where analyzer gets
% information about the network.
if ~(CultureSpace(1) == importNN(1,1) && CultureSpace(2) == importNN(1,2) && ...
    CultureSpace(3) == importNN(1,3) && MinimumNeuronDistance == importNN(2,1) && ...
        NeuroSTD == importNN(3,1) && in0 == importNN(6,1) &&...
        ex0 == importNN(4,1))
    error('Neuronal network parameters do not match the loaded network');
end

if (AstrocyteNetwork == 1)
    pathANT = [TopologyLoadPath, 'AstrocyteNetworkTopology','.csv'];
    pathANC = [TopologyLoadPath, 'AstrocyteNeuronConnections','.csv'];
    pathAC = [TopologyLoadPath, 'AstrocyteConnections','.csv'];
end

% Loading topology data
importT = importdata(pathNNT);
NeuronLocation = squeeze(importT(:,:));
importBN = importdata(pathBN);
BaseNetwork = squeeze(importBN(:,:));
if (AstrocyteNetwork == 1)
    importANT = importdata(pathANT);
    AstrocyteCoordinates = squeeze(importANT(:,:));
    importAC = importdata(pathAC);
    AstrocyteConnections = squeeze(importAC(:,:));
end
numNeur = length(NeuronLocation(1,:));
if (AstrocyteNetwork == 1)
    NumberOfAstrocytes = length(AstrocyteCoordinates(1,:));
    
    AstrocyteNeuronConnections = zeros(numNeur,numNeur,NumberOfAstrocytes);
    importANC = importdata(pathANC);
    for iii = 1:NumberOfAstrocytes
        for i = 1:numNeur
            line = iii * numNeur - numNeur + i;
            for ii = 1:numNeur
                AstrocyteNeuronConnections(i,ii,iii) = squeeze(importANC(line,ii));
            end
        end
    end
end
%% Collecting useful values from the network
% Finding all active synapses
ActiveSynapses = BaseNetwork ~=0;

% Finding all the excitatory and inhibitory synapses in the simulation .
ExcitatorySynapses = BaseNetwork > 0;
InhibitorySynapses = BaseNetwork < 0;

EX_Synapse_Amount = sum(sum(ExcitatorySynapses));
IN_Synapse_Amount = sum(sum(InhibitorySynapses));

% Finding synapse effect. Has values 1 for exitatory, 0 for not
% connected and -1 for negatives.
SynapseEffect = 1*(BaseNetwork > 0) + (-1)*(BaseNetwork < 0);
if (AstrocyteNetwork == 1)

    AmountOfConnections = sum(AstrocyteConnections);
    
    ActivationThreshold = slope * AmountOfConnections + intercept;
    
    AmountOfExcitatoryConnectionsToTheAstrocyte = squeeze(sum(sum(AstrocyteNeuronConnections)))';
    
end

% Counting which synapses are connected to an astrocyte to begin with
SynapsesConnectedToAstrocyte = zeros(numNeur, numNeur); % Tripartite synapse indication matrix
if (AstrocyteNetwork == 1)
    for i = 1:numNeur
        for ii = 1:numNeur            
            if sum(AstrocyteNeuronConnections(i,ii,:)) > 1
                error( ['synapse (' num2str(i) '|' num2str(ii) ') is connected to multiple astrocytes' ] );                
            end  
            SynapsesConnectedToAstrocyte(i,ii) = sum(AstrocyteNeuronConnections(i,ii,:));           
        end
    end
end
%% Calculating metric values of the network

AVGNeuronConnectivity = mean( sum(BaseNetwork));

NeuronAverageConnectionDistance = 0;
if (AstrocyteNetwork == 1)
    AverageSynapsesPerAstrocyte =sum(sum( SynapsesConnectedToAstrocyte ))/NumberOfAstrocytes;
    
    AverageConnectivityOfAstrocytesmean = ( sum(AstrocyteConnections));
    
    MaxAstrocyteDegree = 0;
    
    MinAstrocyteDegree = 0;
    
    AstrocyteAverageDistance = 0;
    
    UnconnectedSynapsesCount = 0;
    
    UnconnectedSynapsesPercentage = 0;
end