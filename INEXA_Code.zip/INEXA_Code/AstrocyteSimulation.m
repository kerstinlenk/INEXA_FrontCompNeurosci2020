%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AstrocyteSimulation.m: Astrocyte effect simulation
% author: Kerstin Lenk & Eero Satuvuori & Antonio Ladron-de-Guevara
% date: 2013-2019, v.0.3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Needs functional preSynapseModel.m file. Uses timeInterval variable from
% the mentioned file.

% Uses information of resources released to synapses. Needs RR matrix from
% preSynapseModel.m as input. Needs Glutamate(Glu) matrix of presynapses for output.

%% IP3 production

% removing IP3 from previous time slice.

IP3 = IP3 * IP3degrading^tinMS;

% Adding IP3 amounts for those synapses that spiked.
IP3 = IP3 + (1-IP3) .* RRtoAstrocyte;

%% Calcium dynamics

% Calcium builds up based on "maximum" concentration of IP3. For example
% Ca concentration 0.7, IP3 level at 0.5, accumulation 10%: the formula
% gives 0.7 + (0.5 - 0.7) * 0.1 resulting in decrease of Ca.

AstrocyteCa = AstrocyteCa + (IP3 - AstrocyteCa)*IP3accumulation;

% Taking into releasing astrocytes matrix all the synapses that were not yet
% over threshold before this at last round AND that went over this round.
ReleasingAstrocytes = (AstrocyteCa > CaGlutamateReleaseLevel).*(~OverThresholdSynapses);

% Calculating the synapses that are now over threshold. Those that went
% under the threshold are again available for release next round.
OverThresholdSynapses = (AstrocyteCa > CaGlutamateReleaseLevel);

%% Glutamate release

%Now the astrocyte releases again fixed amounts but only if certain
%threshold is reached.
Glu = Glu + AstrocyteReleaseAmount .* (1-Glu).* ReleasingAstrocytes;

%% If converging astrocytes are active they are run

if (AstrocyteNetwork)
   
   % Forming a 3D matrix of Ca by replicating all synapse Ca values
   % to all astrocytes 
   CaEffect = repmat(AstrocyteCa,[1,1,NumberOfAstrocytes]);
    
   % Picking only the Ca values representing each astrocyte from the matrix
   TripartiteSynapseCalciums = CaEffect .* AstrocyteNeuronConnections;
   
   % Running astrocyte network model 
   AstrocyteNetworkModel; 
   
   % replicating active astrocytes for all synapses, picking all synapses
   % that are in the area of Ca Wave.
   seed(1,1,:) = (AstrocyteState == 1);
   
   CaWave = sum (repmat(seed,[numNeur,numNeur,1]).* AstrocyteNeuronConnections,3);
   
   % poor execution of inhibition. Will be revised.
   AstrocyteInhibition = sum(CaWave*AstrocyteInhibitionStrength);
   
   % Setting IP3 of the Astrocyte synapse areas within Ca wave to max
   IP3 = IP3.*~CaWave + CaWave;
   
end
