%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INEX_SaveTimestamps.m: Save timestamps in csv-file
% author: Kerstin Lenk
% date: 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(directory)

timestamps = zeros(1,numNeur);

% Part of the spike train which will be saved (memory reasons)
low = 1+(limitSave*ct);
if k == lengthST-(tinMS)+1
    up = k;
else
    up = limitSave*(ct+1);
end

% Transform from time slides to milliseconds
for n = 1:numNeur
    ts = 1;
    for i =low:up
        if spikeTrain(n,i) == 1
            timestamps(ts,n) = i/1000;
            ts = ts+1;
        end
    end   
end

% Write in file
for i = 1:size(timestamps,1)
    for ii = 1:numNeur
        fprintf(fid,'%f;',timestamps(i,ii));
    end
    fprintf(fid,'\n');
end
               
cd(directory2)