%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OptimizedGenerateSpikeTrain.m: Calculates the spikes per time step and neuron 
% author: Kerstin Lenk & Eero Satuvuori & Antonio Ladron-de-Guevara
% date: 2013-2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Output is lastSpike vector as used in main function of INEX. k is the
% time from the beginning in ms +1 and infoNeurons contains all the
% required information about the neuronal network.

function lastspike = OptimizedGenerateSpikeTrain( k,infoNeurons,lastspike, AstrocyteInhibition )

% There is no history before the first spike
if(k == 1)
    lambda(:,1) = infoNeurons.c(:,1);
end

% 2nd to last spike
if(k > 1)
    SpikingWeightsMatrix = zeros(infoNeurons.j,infoNeurons.j);
    
    % First the neuron spiking vector is converted into synapse spiking matrix.
    for i = 1:infoNeurons.j
        
        SpikingWeightsMatrix(:,i) =  infoNeurons.synStr(:,i) .* lastspike(:,1);
        
    end
    sumSyn = sum(SpikingWeightsMatrix) + AstrocyteInhibition;% [ sum of weights effecting each neuron individually ]
    
    
    % lampda = firing rate
    lambda = sumSyn + infoNeurons.c(:,1)';
    
    % taking values higher than zero. result is a vector with 0 for
    % less than zero and 1 for higher than zero. Multiplying each
    % element individually sets negative values to zero.
    lambda = (lambda > 0).*lambda;
end
% Poisson probabilty(resulting as vector)
P = exp(-lambda * infoNeurons.t) .* (lambda * infoNeurons.t);

% Factor times uniformly distributed random number
x = infoNeurons.f.*rand(size(P)); % 
lastspike(:,2) = ( x < P )';

end

