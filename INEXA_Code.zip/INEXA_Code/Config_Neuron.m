%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NeuronConfig.m: Configuration file of the INEX part
% author: Kerstin Lenk
% date: 2013 - 2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Directory for the resulting spike trains
directory = '..\results';

% Length of the spike train in [msec]
lengthST = 300000;

% time interval in [sec] including refractory time
t = 0.005;         

% Number of excitatory neurons
ex0 = 200; 

% Number of inhibitory neurons
in0 = 50;

% Lower and upper boundary of random number for basic activity
c_k = [0.02;0.01;0.02]; 

% Maximal synaptic strength
maxSynStr = 0.7;

% Lower and upper boundary of random number for synaptic strength (all positive numbers)
synStr_oex0 = [maxSynStr;0.2;maxSynStr]; % excitatory, to other neurons, group 0
synStr_oin0 = [maxSynStr;0.2;maxSynStr]; % inhibitory, to other neurons, group 0

% Factor for random variable
sensitivityMultiplier = 0.1;
