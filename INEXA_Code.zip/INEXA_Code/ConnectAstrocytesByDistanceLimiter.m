function AstrocyteConnections = ConnectAstrocytesByDistanceLimiter( AstrocyteCoordinates, connectionDistance )

NumberOfAstrocytes = length(AstrocyteCoordinates(1,:));
AstrocyteConnections = zeros(NumberOfAstrocytes,NumberOfAstrocytes);

for from = 1:NumberOfAstrocytes
    for to = 1:NumberOfAstrocytes
        if from ~= to % no self connections
            
            distance = Distance(AstrocyteCoordinates(:,from), AstrocyteCoordinates(:,to));
            
            if distance < connectionDistance
                
                AstrocyteConnections(from , to) = 1;
                AstrocyteConnections(to,from) = 1;
                
            end
            
        end
    end
end

end

