%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AstrocyteNetworkModel.m: Astrocyte network model
% Mimicing an astrocyte model by Jules Lallouette (2014)
% author: Eero Satuvuori & Kerstin Lenk & Antonio Ladron-de-Guevara
% date: 2013-2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Taking a sum of all the calciums within one astrocyte
CalciumAccumulationFromSynapses = squeeze(sum(sum(TripartiteSynapseCalciums)))';

% Dividing the amount of Ca in synapse areas by the amount of excitatory
% synapses connected to the astrocyte. This gives average value of Ca in
% near synapse areas.
CalciumAccumulationFromSynapses = CalciumAccumulationFromSynapses./...
                                  AmountOfExcitatoryConnectionsToTheAstrocyte;
 
% The average is multiplied by Synapse Effect factor. The stronger the effect 
% of synaptic Ca to glissandi generation is wanted the higher the value.                              
CalciumAccumulationFromSynapses = CalciumAccumulationFromSynapses*SynapseCaEffect;

% Auxiliary variables that arereset each roind
SpontaneouslyActivating = zeros(1,NumberOfAstrocytes);
Activated = zeros(1,NumberOfAstrocytes);
Activating = zeros(1,NumberOfAstrocytes);
ShuttingDown = zeros(1,NumberOfAstrocytes);
Inactivating = zeros(1,NumberOfAstrocytes);
PropagationEfficiency = zeros(1,NumberOfAstrocytes);
FluxOut = zeros(1,NumberOfAstrocytes);


%% Spontaneous activity
% Picking candidates for spontaneous activity
SpontaneouslyActivating = (SpontaneousActivation > rand(1,NumberOfAstrocytes));

% Only the astrocytes in unactivated state can activate
SpontaneouslyActivating = SpontaneouslyActivating .* (AstrocyteState == 0);

%% Evoked activity

% calculating propagation efficiencies
for astrocyte = 1:NumberOfAstrocytes
    
    if AstrocyteState( astrocyte ) == 1
        
        % getting connections to this astrocyte
        connections = AstrocyteConnections(astrocyte, :);
        
        % counting how many of those connected astrocytes are in not active
        % state
        NumberOfInactiveConnections = sum(connections .* ~(AstrocyteState == 1));
        
        % Calculating propagation efficiency
        if (NumberOfInactiveConnections ~= 0)
             PropagationEfficiency(astrocyte) = 1/NumberOfInactiveConnections;
        else
            PropagationEfficiency(astrocyte) = 0;
        end
       
    else
        % If the astrocyte is not active it does not spread the wave
        PropagationEfficiency(astrocyte) = 0;
    end
end

% effect of propagation efficiencies
IP3FluxIn = (PropagationEfficiency * AstrocyteConnections).*ActivationThreshold;

SumOfEfficiencies = IP3FluxIn + SpontaneouslyActivating...
                    + CalciumAccumulationFromSynapses;


% using sum of efficiencies to see which ones have a chance of getting
% activated
Activating = SumOfEfficiencies.*( AstrocyteState == 0 ) > ActivationThreshold;

%% State transitions

% Activation of the astrocytes that A) reached activation threshold, B) get
% random value such that it activates them.
Activated = Activating.* (rand(1,NumberOfAstrocytes) < ActivationProbability);

% Adding the activated astrocytes to state vector.
AstrocyteState = AstrocyteState + Activated;

% Adding the sum of activated astrocytes this round to the sum of those
% activated during the whole simulation.
AmountOfAstrocytesActivatedInSimulation = AmountOfAstrocytesActivatedInSimulation +sum(Activated);

% Astrocytes shutting down their glissandi
ShuttingDown = (AstrocyteState == 1) .* (rand(1,NumberOfAstrocytes) < ActivationTime );
% going from state 1 to -1
AstrocyteState = AstrocyteState -2*ShuttingDown;

% Refractory
Inactivating = (AstrocyteState == -1) .* (rand(1,NumberOfAstrocytes) < RefractoryTime);
% going from state -1 to 0
AstrocyteState = AstrocyteState + Inactivating ;
%% Saving progress

ActivityAnimation(:,AnimationFrame) = AstrocyteState';

AnimationFrame = AnimationFrame+1;
