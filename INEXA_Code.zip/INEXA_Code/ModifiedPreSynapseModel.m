%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ModifiedPreSynapseModel.m: Presynapse model based on De Pitta model
% author: Eero Satuvuori & Kerstin Lenk & Antonio Ladron-de-Guevara
% date: 2013-2019, v.1.3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% MUST BE USED WITH AstrocyteSetConfig v.1.2!!!

% According to INEX model t2 is the time interval of time slots in ms. That
% value is used in the model together with lastspike data taken to
% spikeVector(column vector) variable.
if(sum(spikeVector) > 0)
    %% Glutamate and spike effect computation
    
    % calculating alpha
    
    Alpha = ExcitatorySynapses .*alpha;
    
    % calculating weights of exitatory synapses based on glutamate amount. Used
    % for astrocyte simulator and to the next function internally.
    Ualpha = w.* ExcitatorySynapses .*(1 - Glu)+ Alpha .* Glu;
    
    % adding inhibitory neurons to the matrix. They are constants.
    Umatrix = w.*( w < 0 ) + Ualpha;
    
    % First the neuron spiking vector is converted into synapse spiking matrix.
    for i = 1:numNeur
        SpikingMatrix(:,i) =  ActiveSynapses(:,i) .* spikeVector;
    end
    
    %% Calculating amounts of calcium in EACH synapse after spiking
    
    % Taking into account only the synapses spiking. AUX represents U of the
    % spiking synapses in this block
    AUX = Umatrix.*SpikingMatrix.*(1-u);
    
    % swapping "negative U" values to positive. Calcium builds up the same in both
    % neuron types.
    AUX = SynapseEffect.*AUX;
    
    % adding calcium to sensors. At this point the matrix has again values for
    % synapses that are not spiking.
    u = u + AUX;
    
    %% New Weights computation
    
    % Using information of amounts of calcium and which neurons
    % are spiking together with resources available for computing
    % new weights for synapses.
    % redefining matrix a according to resources released in spikes.
    % AUX is the resources what would be released from the synapses.
    AUX = u .* x;
    
    % releasing from the synapses actually spiking
    RR = AUX .* SpikingMatrix;
    
    % matrix a is resources released in synapse times the effect of the synapse
    % and taking only those that are spiking this slot.
    returnValue = SynapseEffect .* RR.* ScalingMatrix;

    % Removing resources from matrix x according to used resources.
    
    x = x - RR;
  
    %% Astrocyte simulator call with new values
    % The rest of the blocks are calculated each round.
    %If there was no spiking a = [0];

else
    RR = zeros(numNeur,numNeur);
    returnValue = zeros(numNeur,numNeur);
end
%% Regenerate resources

if(preSynapse)
    %regenerating resources available
    for i = 1:tinMS
        x = x + (1-x) .* RegenRes .*ActiveSynapses;
    end
    % removing Ca from presynapse
    u = u .* (CaRegen^(tinMS)).*ActiveSynapses;
end

if(Astrocyte)
         
    % needs synaptic glutamate release as an RR matrix.
    % output is stored to Glu matrix.
    if(AstrocyteNetwork)
    RRtoAstrocyte = RR .* SynapsesConnectedToAstrocyte;
    else
    RRtoAstrocyte = RR .* ExcitatorySynapses;
    end
    
    AstrocyteSimulation;
        
    Glu = Glu .*GlutamateRemoval^(tinMS);
    
end
