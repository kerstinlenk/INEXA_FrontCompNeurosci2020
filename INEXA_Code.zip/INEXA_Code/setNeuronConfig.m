%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% setNeuronConfig.m: Preparations for generations of spike trains
% author: Kerstin Lenk & Eero R�is�nen
% date: 2013 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Spike counter
count = zeros(numNeur,1);  

% Variable definition
lastspike = zeros(numNeur,2); 
spikes = zeros(numNeur,lengthST/tinMS);
counter = 1;

% Basic activity of all neurons which is a random number between 0 and an 
% upper boundary from a triangular distribution
for i = 1:numNeur
    c(i,1) = BaseBasicActivity(i,1)*p_c;
end

% Excitatory synaptic strengths is a random number between 0 and an 
% upper boundary from a triangular distribution
for i = 1:ex0 % Group 1
    for ii = 1:numNeur
        if i ~=ii
           synStr(i,ii) = BaseNetwork(i,ii)*p_oex0;
        else
            synStr(i,ii) = 0; % Autapses
        end
    end
end

% Inhibitory synaptic strengths is a random number between 0 and an 
% upper boundary from a triangular distribution
for i = ex0+1:in0+ex0 % Group 1
    for ii = 1:numNeur
        if i ~=ii
            synStr(i,ii) = BaseNetwork(i,ii)*p_oin0;
        else
            synStr(i,ii) = 0; % Autapses
        end
    end
end

%% For saving time stamps
counterSave = 1;
ct = 0;
limitSave = 360000;

%% Output
cd(directory)
fid = fopen(['timestamps_',num2str(p_c,'%.4f'),'_',num2str(p_oex0 ,'%.4f'),...
    '_',num2str(p_oin0,'%.4f'),'.csv'],'wt');
for h = 1:numNeur
    fprintf(fid,'%i;',h);
end
fprintf(fid,'\n');
cd(directory2)