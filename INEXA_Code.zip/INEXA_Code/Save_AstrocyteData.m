cd(directory)
fidAstro = fopen(['AstroData_',num2str(p_c,'%.4f'),'_',num2str(p_oex0 ,'%.4f'),...
    '_',num2str(p_oin0,'%.4f'),'.csv'],'wt');

% Write in file

if(preSynapse)
    %SAVEASTROMATRIX = [ASTRODATA1;ASTRODATA2;ASTRODATA3;ASTRODATA4;ASTRODATA5;ASTRODATA6];
    SAVEASTROMATRIX = [ASTRODATA1;ASTRODATA2;ASTRODATA3;ASTRODATA4;ASTRODATA5;ASTRODATA6;ASTRODATA7;ASTRODATA8;ASTRODATA9;ASTRODATA10;ASTRODATA11;ASTRODATA12;ASTRODATA13];

    NextFreeLine = 1;
    
    %for i = NextFreeLine:6
    for i = NextFreeLine:13
        for ii = 1:length(ASTRODATA1)
            fprintf(fidAstro,'%f;',SAVEASTROMATRIX(i,ii));
        end
        fprintf(fid,'\n');
        
    end
    %NextFreeLine = NextFreeLine + 6;
    NextFreeLine = NextFreeLine + 13;    

    if(AstrocyteNetwork)
        for i = 1:NumberOfAstrocytes
            for ii = 1:length(ActivityAnimation(i,:))
                
                fprintf(fidAstro,'%f;', ActivityAnimation(i,ii));
                
            end
            fprintf(fid,'\n');
            
        end
        
        for i =  1:NumberOfAstrocytes
            for ii = 1:NumberOfAstrocytes
                
                fprintf(fidAstro,'%f;', AstrocyteConnections(i,ii));
                
            end
            fprintf(fid,'\n');
        end
        
        for i = 1:3
            for ii = 1:NumberOfAstrocytes
                
                fprintf(fidAstro,'%f;', AstrocyteCoordinates(i,ii));
                
            end
            fprintf(fid,'\n');
        end
    end
    fclose(fidAstro);
end
cd(directory2)
